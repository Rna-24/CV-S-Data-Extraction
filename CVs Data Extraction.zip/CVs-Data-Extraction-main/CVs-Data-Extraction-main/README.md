# CV-S-Data-Extraction
uilt a robot to extract names, phones, emails, addresses, and job titles from PDF CVs using Gen AI and UiPath’s Extract Document Data activity.
